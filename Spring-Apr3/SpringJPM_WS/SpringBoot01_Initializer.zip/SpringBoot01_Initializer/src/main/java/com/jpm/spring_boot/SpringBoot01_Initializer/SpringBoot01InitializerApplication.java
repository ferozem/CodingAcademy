package com.jpm.spring_boot.SpringBoot01_Initializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot01InitializerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot01InitializerApplication.class, args);
	}

}

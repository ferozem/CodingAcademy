package com.smita.springboot.SpringBoot2_Secured_JPA_Rest0006;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2SecuredJpaRest0006Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2SecuredJpaRest0006Application.class, args);
	}

}

package com.smita.springboot.SpringBoot2_Secured_JPA_Rest0006;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBoot2SecuredJpaRest0006ApplicationTests {

	@Test
	public void contextLoads() {
	}

}

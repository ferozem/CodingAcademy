package com.boot.dasboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DasBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DasBootApplication.class, args);
	}

}

package com.jpm.spring.SpringBoot_Home01_Basics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHome01BasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHome01BasicsApplication.class, args);
	}

}
